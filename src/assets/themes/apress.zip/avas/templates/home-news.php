<?php
/**
* 
* @package bddex
* @author theme-x
* @link https://x-theme.com/
 *
 * Template Name: Home - News Header
 */
global $bddex;
get_header();
?>
<div class="container space_news">
    <div class="row">
        <?php bddex_content_page(); ?>
    </div><!-- row -->
</div>   <!-- container -->
<?php get_footer(); 