 <?php global $apress_data, $woocommerce; ?>

<?php if ( is_active_sidebar( 'footer_widget1' ) ) { ?>
<div class="zolo_footer_row">
<div class="footercolumn footer_column1"><?php dynamic_sidebar('footer_widget1'); ?></div>
</div>
<?php }?>