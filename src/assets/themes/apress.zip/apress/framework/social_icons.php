 <?php global $apress_data; 
 $target = '_blank';
 ?>
 
 <?php if($apress_data['facebook_link'] || $apress_data['flickr_link'] || $apress_data['rss_link'] || $apress_data['twitter_link'] || $apress_data['vimeo_link'] || $apress_data['youtube_link'] || $apress_data['instagram_link'] || $apress_data['pinterest_link'] || $apress_data['tumblr_link'] || $apress_data['google_link'] || $apress_data['dribbble_link'] || $apress_data['digg_link'] || $apress_data['linkedin_link'] || $apress_data['skype_link'] || $apress_data['deviantart_link'] || $apress_data['yahoo_link'] || $apress_data['reddit_link'] || $apress_data['dropbox_link'] || $apress_data['soundcloud_link'] || $apress_data['vk_link'] || $apress_data['whatsapp_link'] || $apress_data['email_link'] || $apress_data['bbb_link'] || $apress_data['thumbtack_link'] || $apress_data['angie_link'] || $apress_data['home_adv_link']|| $apress_data['yelp_link']){ 
 
if($apress_data['header_social_links_boxed'] == 'Yes'){
	$boxed_icons = 'boxed-icons';
}else{
	$boxed_icons = '';
	}

echo '<li class="zolo-social '.$boxed_icons.'">';
?><ul class="social-icon">
        <?php if($apress_data['facebook_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['facebook_link']); ?>"><i class="fa fa-facebook"></i></a></li>
        <?php endif; ?>
        
        <?php if($apress_data['flickr_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['flickr_link']); ?>" ><i class="fa fa-flickr"></i></a></li>
        <?php endif; ?>
        
        <?php if($apress_data['rss_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['rss_link']); ?>" ><i class="fa fa-rss"></i></a></li>
        <?php endif; ?>
        
        <?php if($apress_data['twitter_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['twitter_link']); ?>" ><i class="fa fa-twitter"></i></a></li>
        <?php endif; ?>
        
        <?php if($apress_data['vimeo_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['vimeo_link']); ?>"><i class="fa fa-vimeo-square"></i></a></li>
        <?php endif; ?>
        
        <?php if($apress_data['youtube_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['youtube_link']); ?>"><i class="fa fa-youtube"></i></a></li>
        <?php endif; ?>
        
        <?php if($apress_data['instagram_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['instagram_link']); ?>"><i class="fa fa-instagram"></i></a></li>
        <?php endif; ?>
        
        <?php if($apress_data['pinterest_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['pinterest_link']); ?>"><i class="fa fa-pinterest"></i></a></li>
        <?php endif; ?>
        
        <?php if($apress_data['tumblr_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['tumblr_link']); ?>"><i class="fa fa-tumblr"></i></a></li>
        <?php endif; ?>
        
        <?php if($apress_data['google_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['google_link']); ?>"><i class="fa fa-google-plus"></i></a></li>
        <?php endif; ?>
        
        <?php if($apress_data['dribbble_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['dribbble_link']); ?>"><i class="fa fa-dribbble"></i></a></li>
        <?php endif; ?>
        
        <?php if($apress_data['digg_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['digg_link']); ?>"><i class="fa fa-digg"></i></a></li>
        <?php endif; ?>
        
        <?php if($apress_data['linkedin_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['linkedin_link']); ?>"><i class="fa fa-linkedin"></i></a></li>
        <?php endif; ?>
        
        <?php if($apress_data['skype_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['skype_link']); ?>"><i class="fa fa-skype"></i></a></li>
        <?php endif; ?>        
        
		<?php if($apress_data['deviantart_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['deviantart_link']); ?>"><i class="fa fa-deviantart"></i></a></li>
        <?php endif; ?>
                
        <?php if($apress_data['yahoo_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['yahoo_link']); ?>"><i class="fa fa-yahoo"></i></a></li>
        <?php endif; ?>  
        
        <?php if($apress_data['reddit_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['reddit_link']); ?>" ><i class="fa fa-reddit"></i></a></li>
        <?php endif; ?>

        <?php if($apress_data['dropbox_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['dropbox_link']); ?>" ><i class="fa fa-dropbox"></i></a></li>
        <?php endif; ?>
        
        <?php if($apress_data['soundcloud_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['soundcloud_link']); ?>" ><i class="fa fa-soundcloud"></i></a></li>
        <?php endif; ?>
                
        <?php if($apress_data['vk_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['vk_link']); ?>" ><i class="fa fa-vk"></i></a></li>
        <?php endif; ?>
        
        <?php if($apress_data['whatsapp_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['whatsapp_link']); ?>" ><i class="fa fa-whatsapp"></i></a></li>
        <?php endif; ?>
        
         <?php if(isset($apress_data['github_link']) && $apress_data['github_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['github_link']); ?>" ><i class="fa fa-github"></i></a></li>
        <?php endif; ?>
        
        <?php if(isset($apress_data['behance_link']) && $apress_data['behance_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['behance_link']); ?>" ><i class="fa fa-behance"></i></a></li>
        <?php endif; ?>
        
        <?php if(isset($apress_data['500px_link']) && $apress_data['500px_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['500px_link']); ?>" ><i class="fa fa-500px"></i></a></li>
        <?php endif; ?>
        
        <?php if(isset($apress_data['xing_link']) && $apress_data['xing_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['xing_link']); ?>" ><i class="fa fa-xing"></i></a></li>
        <?php endif; ?>
        
        <?php if(isset($apress_data['yelp_link']) && $apress_data['yelp_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['yelp_link']); ?>" >        
        <svg id="Bold" enable-background="new 0 0 24 24" height="20px" viewBox="0 0 24 24" width="20px" xmlns="http://www.w3.org/2000/svg"><path d="m12.062 17.662c.038-.934-1.266-1.395-1.829-.671-1.214 1.466-3.493 4.129-3.624 4.457-.347 1 1.28 1.638 2.312 2.024 1.121.42 1.919.591 2.392.51.342-.071.562-.248.67-.533.089-.245.08-5.568.079-5.787z"/><path d="m11.522.642c-.08-.31-.295-.51-.647-.6-1.037-.272-4.966.838-5.698 1.624-.234.238-.318.515-.248.828l4.985 8c1.018 1.628 2.298 1.139 2.214-.681h-.001c-.066-1.199-.544-8.775-.605-9.171z"/><path d="m9.413 15.237c.942-.29.872-1.671.07-1.995-2.139-.881-5.06-2.114-5.285-2.114-.876-.052-1.045 1.201-1.134 2.096-.08.81-.084 1.552-.014 2.229.066.714.221 1.443.933 1.485.309-.001 5.383-1.686 5.43-1.701z"/><path d="m20.514 12.052c.403-.281.342-.7.347-.838-.108-1.024-1.83-3.61-2.692-4.029-.328-.152-.614-.143-.858.029-.323.219-3.24 4.444-3.413 4.619-.567.767.244 1.871 1.092 1.648l-.014.029c.341-.115 5.274-1.282 5.538-1.458z"/><path d="m15.321 15.586c-.881-.315-1.712.81-1.2 1.581.145.247 2.809 4.705 3.043 4.871.225.191.507.219.83.095.905-.362 2.865-2.876 2.992-3.857.051-.348-.042-.619-.286-.814-.197-.176-5.379-1.876-5.379-1.876z"/></svg>
        </a></li>
        <?php endif; ?>
        
        
        <?php if(isset($apress_data['bbb_link']) && $apress_data['bbb_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['bbb_link']); ?>" >
<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 44.7 44.7" width="20px" height="20px" xml:space="preserve">
	<g>
		<g>
			<path d="M23.789,18.542c-1.404-1.361-4.727-2.095-5.085-4.423c0.082-0.318-0.278-0.348-0.326-0.221
			c-0.987,2.685-5.978,5.777,0.684,9.344c1.541,0.92,3.533,2.068,3.314,3.754c-0.083,0.215,0.11,0.244,0.258,0.069
			C24.828,24.551,26.476,20.954,23.789,18.542z" />
		</g>
	</g>
	<g>
		<g>
			<path d="M30.329,8.328c-2.217-2.398-6.766-3.98-7.674-6.257c-0.175-0.441,0.019-1.08,0.261-1.583
			c0.15-0.36-0.157-0.515-0.354-0.484c-0.102-0.015-0.2,0.011-0.237,0.077c-1.922,3.985-8.769,7.855-0.33,14.016
			c2.33,1.732,6.236,2.769,4.238,6.846c-0.121,0.215-0.013,0.322,0.159,0.291c0.089,0.021,0.224-0.021,0.353-0.128
			C29.595,17.801,34.232,12.586,30.329,8.328z" />
		</g>
	</g>
	<g>
		<g>
			<polygon points="30.676,27.991 30.66,28.049 13.895,28.049 13.88,27.991 13.137,30.079 13.859,30.089 13.859,30.115 
			17.612,30.115 18.649,32.932 25.943,32.908 26.895,30.115 30.688,30.115 30.689,30.089 31.418,30.079 		" />
		</g>
	</g>
	<g>
		<g>
			<path d="M34.271,39.595c2.302-1.715,0.933-4.897-0.844-4.848l-3.6-0.031h-2.188V44.7h2.221v-0.009l3.909-0.062
			C36.242,44.622,37.342,40.454,34.271,39.595z M29.859,38.686V36.44l2.752,0.058c0.944-0.006,1.379,2.248-0.031,2.188H29.859z
			 M33.019,42.908l-3.159-0.025v-2.325l3.19-0.058C34.295,40.517,34.218,42.945,33.019,42.908z" />
		</g>
	</g>
	<g>
		<g>
			<path d="M24.781,39.595c2.301-1.715,0.934-4.897-0.845-4.848l-3.597-0.031h-0.002h-2.188V44.7h2.221v-0.009l3.911-0.062
			C26.754,44.622,27.853,40.454,24.781,39.595z M20.371,36.44l2.752,0.058c0.943-0.006,1.381,2.248-0.03,2.188h-2.722V36.44z
			 M23.53,42.908l-3.16-0.025v-2.325l3.191-0.058C24.806,40.517,24.729,42.945,23.53,42.908z" />
		</g>
	</g>
	<g>
		<g>
			<path d="M15.19,39.595c2.301-1.715,0.935-4.897-0.845-4.848l-3.597-0.031h-0.001H8.559V44.7h2.22v-0.009l3.91-0.062
			C17.163,44.622,18.262,40.454,15.19,39.595z M10.78,36.44l2.751,0.058c0.942-0.006,1.379,2.248-0.031,2.188h-2.72V36.44z
			 M13.939,42.908l-3.159-0.025v-2.325l3.19-0.058C15.215,40.517,15.138,42.945,13.939,42.908z" />
		</g>
	</g>
	<g></g>
	<g></g>
	<g></g>
	<g></g>
	<g></g>
	<g></g>
	<g></g>
	<g></g>
	<g></g>
	<g></g>
	<g></g>
	<g></g>
	<g></g>
	<g></g>
	<g></g>
</svg></a></li>
        <?php endif; ?>
        
        <?php if(isset($apress_data['thumbtack_link']) && $apress_data['thumbtack_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['thumbtack_link']); ?>" >
<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="20px" height="20px" viewBox="0 0 319.808 319.808" style="enable-background:new 0 0 319.808 319.808;" xml:space="preserve">
	<g>
		<path d="M317.16,159.471c-16.197-16.199-41.195-24.41-74.307-24.41c-7.01,0-14.408,0.379-22.047,1.121l-79.729-75.346l19.04-19.035
		c3.529-3.531,3.529-9.252-0.003-12.785l-26.42-26.424c-3.39-3.391-9.394-3.391-12.784,0L2.648,120.863
		c-3.531,3.531-3.531,9.252-0.002,12.783l26.416,26.416c1.697,1.695,3.995,2.648,6.394,2.648c2.397,0,4.697-0.953,6.392-2.648
		l19.042-19.035l75.346,79.726c-3.048,31.352-1.057,72.018,23.284,96.358c1.766,1.766,4.079,2.648,6.391,2.648
		c2.314,0,4.629-0.884,6.395-2.648l66.035-66.041l50.578,50.582c1.768,1.766,4.08,2.648,6.395,2.648
		c2.312,0,4.629-0.884,6.393-2.648c3.531-3.531,3.531-9.254,0-12.785l-50.582-50.58l66.037-66.03
		C320.691,168.725,320.691,163.005,317.16,159.471z M166.505,297.334c-14.614-21.172-14.7-53.803-11.859-78.743
		c0.3-2.648-0.581-5.297-2.413-7.23l-84.589-89.516c-1.678-1.775-4.002-2.791-6.443-2.826c-0.042,0-0.086,0-0.128,0
		c-2.397,0-4.697,0.953-6.392,2.647l-19.225,19.221l-13.632-13.631L127.303,21.769l13.636,13.641L121.716,54.63
		c-1.726,1.73-2.68,4.078-2.646,6.525c0.035,2.436,1.057,4.768,2.832,6.443l89.507,84.582c1.936,1.836,4.574,2.719,7.23,2.41
		c8.455-0.963,16.602-1.449,24.213-1.449c23.465,0,41.756,4.469,54.539,13.314L166.505,297.334z" />
	</g>
	<g></g>
	<g></g>
	<g></g>
	<g></g>
	<g></g>
	<g></g>
	<g></g>
	<g></g>
	<g></g>
	<g></g>
	<g></g>
	<g></g>
	<g></g>
	<g></g>
	<g></g>
</svg></a></li>
        <?php endif; ?>
        
        <?php if(isset($apress_data['angie_link']) && $apress_data['angie_link']): ?>
        <li class="social_icon_list angie_link"><a target="_blank" href="<?php echo esc_url($apress_data['angie_link']); ?>" ><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="20" height="20" viewBox="0 0 66 48" fill="#fff" fill-rule="evenodd" stroke="#000" stroke-linecap="round" stroke-linejoin="round"><use xlink:href="#A" x=".5" y=".5"/><symbol id="A" overflow="visible"><path d="M49.23 22.154H25.6l-2.954 11.323-2.954-11.323h-5.415c-4.43 0-7.877-3.446-7.877-7.877S9.846 6.4 14.277 6.4H49.23c4.43 0 7.877 3.446 7.877 7.877s-3.446 7.877-7.877 7.877M49.23 0H14.277C6.395.007.007 6.395 0 14.277c.007 7.882 6.395 14.27 14.277 14.277h1.477l6.892 17.723 6.892-17.723h20.185c7.882-.007 14.27-6.395 14.277-14.277C63.508 6.4 57.108 0 49.23 0" stroke="none" fill-rule="nonzero"/></symbol></svg></a></li>
        <?php endif; ?>
        
        <?php if(isset($apress_data['home_adv_link']) && $apress_data['home_adv_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="<?php echo esc_url($apress_data['home_adv_link']); ?>" ><svg data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 65 55" width="20px" height="20px">
    <path d="M42.671 50.76c-.726-.711-1.37-1.338-2.01-1.97q-4.668-4.602-9.328-9.211a.869.869 0 0 0-.683-.238q-7.35.005-14.7.004a3.166 3.166 0 0 1-3.028-1.78 2.999 2.999 0 0 1-.345-1.305c-.027-4.081-.02-8.163-.01-12.245a.683.683 0 0 1 .19-.434q3.046-3.03 6.11-6.045c1.516-1.497 3.04-2.986 4.552-4.487.65-.644 1.277-1.31 1.951-2.004.263.245.484.44.693.647q4.471 4.415 8.94 8.833 3.033 2.994 6.08 5.973a.89.89 0 0 0 .568.213q5.22.02 10.439.001c.36-.001.466.083.463.456-.016 2.938-.008 5.876-.01 8.814a3.246 3.246 0 0 1-3.338 3.359c-1.999.01-3.997.002-5.996.003-.537 0-.537.001-.537.54v10.33z" />
    <path d="M25.116 6.613l17.34 16.834H62.25L42.527 3.362H22.515L2.25 23.447h5.903L25.116 6.613z"/>
</svg></a></li>
        <?php endif; ?>
        
        <?php if($apress_data['email_link']): ?>
        <li class="social_icon_list"><a target="_blank" href="mailto:<?php echo esc_attr($apress_data['email_link']); ?>" ><i class="fa fa-envelope-o"></i></a></li>
        <?php endif; ?>
        
      </ul>

<?php 
	echo '</li>';	
}?>