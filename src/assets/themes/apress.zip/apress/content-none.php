<?php
/**
* 
* @package bddex
* @author theme-x
* @link https://x-theme.com/
*
*/

?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <div class="entry-content">
        <h4 class="center"><?php esc_html_e( 'Sorry, nothing found.', 'avas' ); ?></h4>
    </div><!-- .entry-content -->
</article><!-- #post-## -->