<?php
/**
* 
* @package bddex
* @author theme-x
* @link https://x-theme.com/
 *
 * Template Name: No Header Footer
 */
global $bddex;
get_header();
?>
<div class="container">
    <div class="row">
        <?php bddex_content_page(); ?>
    </div>
</div>   
<?php get_footer(); 