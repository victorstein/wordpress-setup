<?php
/**
 * Single Custom Post Type Page Links
 *
 * @package Total WordPress theme
 * @subpackage Partials
 * @version 4.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

wpex_get_template_part( 'link_pages' );