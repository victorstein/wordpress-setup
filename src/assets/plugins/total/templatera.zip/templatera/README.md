VC-Template-Manager
===================

Template management for WPBakery Page Builder
