<?php
/**
* 
* @package bddex
* @author theme-x
* @link https://x-theme.com/
 *
 * Template Name: Main Header
 */
global $bddex;
get_header();
?>
<div class="container mt40">
    <div class="row">
        <?php bddex_content_page(); ?>
    </div>
</div>   
<?php get_footer(); 