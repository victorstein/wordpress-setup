-----------------------------------
Please read the documentation <a href="https://x-theme.com/doc-avas/" target="_blank">here</a> where you'll find clear instruction to setup the theme and demo. 


You may check our <a href="https://www.youtube.com/channel/UC1hlWYgndZw7PEHWeTbYvfA/videos" target="_blank">video tutorial</a> as well.

Any theme related issue please send us a message via our themeforest <a href="https://themeforest.net/item/avas-multi-purpose-responsive-wordpress-theme/19775390/support" target="_blank">support</a> page.


